import React from "react";
import "./Category.css";

const Category = () => {
  return (
    <div className="grid gap-8 container !my-6 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-4">
      <div className="women h-48 w-full p-5 relative hover:translate-y-[-15px] duration-500">
        <span className="uppercase block absolute right-5 font-medium top-5 text-sm border-2 border-[#2323231a] px-3.5 py-1 rounded-full">
          8 items
        </span>
        <h2 className="capitalize bg-white mt-22 m-auto font-medium w-36 h-11 rounded text-center items-center justify-center flex">
          women
        </h2>
      </div>

      <div className="men h-48 w-full p-5 relative hover:translate-y-[-15px] duration-500">
        <span className="uppercase block absolute right-5 font-medium top-5 text-sm border-2 border-[#2323231a] px-3.5 py-1 rounded-full">
          8 items
        </span>
        <h2 className="capitalize bg-white mt-22 m-auto font-medium w-36 h-11 rounded text-center items-center justify-center flex">
          men
        </h2>
      </div>

      <div className="accessories h-48 w-full p-5 relative hover:translate-y-[-15px] duration-500">
        <span className="uppercase block absolute right-5 font-medium top-5 text-sm border-2 border-[#2323231a] px-3.5 py-1 rounded-full">
          8 items
        </span>
        <h2 className="capitalize bg-white mt-22 m-auto font-medium w-36 h-11 rounded text-center items-center justify-center flex">
          accessories
        </h2>
      </div>

      <div className="kids h-48 w-full p-5 relative hover:translate-y-[-15px] duration-500">
        <span className="uppercase block absolute right-5 font-medium top-5 text-sm border-2 border-[#2323231a] px-3.5 py-1 rounded-full">
          8 items
        </span>
        <h2 className="capitalize bg-white mt-22 m-auto font-medium w-36 h-11 rounded text-center items-center justify-center flex">
          kids
        </h2>
      </div>
    </div>
  );
};

export default Category;
