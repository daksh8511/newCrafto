import React from "react";
import { BestSellerProductData } from "./BestSellerProductData";

const BestSellerProduct = () => {
  return (
    <section>
      <div className="py-15 container">
        <h2 className="text-center min-sm:text-2xl min-md:text-5xl">
          Best seller{" "}
          <span className="font-bold border-b-4 border-[#fee300]">
            products
          </span>
        </h2>
        <div className="grid gap-7 mt-15 sm:grid-cols-1 md:grid-cols-3 lg:grid-cols-5">
          {BestSellerProductData.map((item, i) => {
            return (
              <div>
                <img className="w-full" src={item.image} alt="" />
                <h3 className="text-center mt-4 mb-2 font-bold">
                  {item.productName}
                </h3>
                <div className="flex justify-center gap-3">
                  <del className="text-[#828282] text-lg">{item.delPrice}</del>
                  <h4 className="text-[#828282] text-lg">{item.price}</h4>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default BestSellerProduct;
