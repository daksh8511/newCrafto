import React, { useState } from "react";
import "./ArrivalCollection.css";

import { Swiper, SwiperSlide } from "swiper/react";

// Import Swiper styles
import "swiper/css";
import "swiper/css/scrollbar";
import { Pagination, Autoplay } from "swiper/modules";

const ArrivalCollection = () => {

  return (
    <section className="bg-[#f7f7f7]">
    <div className="container py-20 relative overflow-hidden">
      <div className="w-full flex max-sm:block max-md:block">
        <div className="left_side pe-10 ps-5 ">
          <h5 className="lookbook mb-2.5 font-bold">Lookbook 2023</h5>
          <h3 className="text-6xl mb-3">
            New arrival <span className="font-bold">collection</span>
          </h3>
          <p className="mb-3 leading-8 text-xl text-[#828282]">
            Flash summer sale 70% off on selected collection for him.
          </p>
          <button className="capitalize bg-[#232323] text-white text-md py-3 px-6 max-md:mb-10">
            view collection
          </button>
        </div>
        <div className="right_side w-[75%] max-md:h-[300px] max-md:w-[100%]">
          <Swiper
            slidesPerView={3}
            loop={true}
            autoplay={{
              delay: 2500,
              disableOnInteraction: false,
            }}
            breakpoints={{
              0:{
                slidesPerView : 1
              },
              576: {
                slidesPerView: 1,
              },
              768: {
                slidesPerView: 2,
              },
              1024: {
                slidesPerView : 3
              }
            }}
            spaceBetween={30}
            pagination={{
              clickable: true,
            }}
            modules={[Pagination, Autoplay]}
            className="mySwiper h-full"
          >
            <SwiperSlide className="slider1 rounded-xl">
              <span className="absolute w-full h-full bg-gradient-to-b from-white to-black opacity-[0.5] "></span>
              <h4 className="z-10 absolute text-white bottom-15 left-10 font-bold text-xl">
                Ethenic Wear
              </h4>
              <h5 className="uppercase z-10 absolute text-gray-400 font-semibold bottom-8 left-10 text-sm">
                outfits matching
              </h5>
            </SwiperSlide>
            <SwiperSlide className="slider2 rounded-xl">
              <span className="absolute w-full h-full bg-gradient-to-b from-white to-black opacity-[0.5] "></span>
              <h4 className="z-10 absolute text-white bottom-15 left-10 font-bold text-xl">
                Dress Materials
              </h4>
              <h5 className="uppercase z-10 absolute text-gray-400 font-semibold bottom-8 left-10 text-sm">
                explore a veriety
              </h5>
            </SwiperSlide>
            <SwiperSlide className="slider3 rounded-xl">
              <span className="absolute w-full h-full bg-gradient-to-b from-white to-black opacity-[0.5] "></span>
              <h4 className="z-10 absolute text-white bottom-15 left-10 font-bold text-xl">
                Western Wear
              </h4>
              <h5 className="uppercase z-10 absolute text-gray-400 font-semibold bottom-8 left-10 text-sm">
                tradition Attires
              </h5>
            </SwiperSlide>
            <SwiperSlide className="slider4 rounded-xl">
              <span className="absolute w-full h-full bg-gradient-to-b from-white to-black opacity-[0.5] "></span>
              <h4 className="z-10 absolute text-white bottom-15 left-10 font-bold text-xl">
                Loungewear
              </h4>
              <h5 className="uppercase z-10 absolute text-gray-400 font-semibold bottom-8 left-10 text-sm">
                women branded
              </h5>
            </SwiperSlide>
          </Swiper>
        </div>
      </div>
      <h2 className="text-[#828282] text-[9rem] opacity-0 min-sm:opacity-[0.3] absolute bottom-[-80px] font-black">new collection</h2>
    </div>
    </section>
  );
};

export default ArrivalCollection;
