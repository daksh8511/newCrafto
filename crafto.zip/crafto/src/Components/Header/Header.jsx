import React, { useState } from "react";

import "./Header.css";

import logo from "/assets/logo.png";

import { IoLocationOutline, IoCloseOutline } from "react-icons/io5";
import { IoIosSearch } from "react-icons/io";
import { FaInstagram, FaRegUser } from "react-icons/fa";
import { FiShoppingBag } from "react-icons/fi";
import { RiMenu5Fill } from "react-icons/ri";

const Header = () => {
  const [closeActive, setCloseActive] = useState(false);

  const handleMenu = () => {
    if (closeActive == true) {
      setCloseActive(false);
    } else {
      setCloseActive(true);
    }
  };
  return (
    <header>
      <div className="container flex justify-between items-center py-5">
        <div className="box gap-5 *:text-xl *:hover:opacity-[0.6] *:duration-300 *:cursor-pointer hidden min-lg:flex">
          <IoLocationOutline />
          <FaInstagram />
        </div>
        <div className="menu flex gap-14 items-center">
          <ul className="firstmenu  gap-5 *:font-semibold *:cursor-pointer *:duration-300 hidden min-lg:flex">
            <li className="active">Home</li>
            <li>Shop</li>
            <li>Collection</li>
          </ul>
          <img src={logo} alt="" />
          <ul className="secmenu hidden gap-5 *:font-semibold *:cursor-pointer *:duration-300 min-lg:flex">
            <li>Magazine</li>
            <li className="relative pages">
              Pages
              <ul className="sub_menu absolute w-[300px] bg-white p-5 shadow-2xl hidden">
                <li>About</li>
                <li>Faq</li>
                <li>Wishlist</li>
                <li>Account</li>
                <li>Cart</li>
                <li>Checkout</li>
              </ul>
            </li>
            <li>Contact</li>
          </ul>
        </div>
        <div className="box flex gap-5 *:text-xl *:hover:opacity-[0.6] *:duration-300 *:cursor-pointer">
          <IoIosSearch />
          <FaRegUser />
          <FiShoppingBag />
        </div>
      </div>
      <div className="container">
        <div className="min-lg:hidden">
          {closeActive == true ? (
            <RiMenu5Fill onClick={handleMenu} className="text-3xl mt-5" />
          ) : (
            <IoCloseOutline onClick={handleMenu} className="text-3xl mt-5" />
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;
