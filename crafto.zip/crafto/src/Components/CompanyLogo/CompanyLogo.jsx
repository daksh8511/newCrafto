import React from "react";

import asos from "/assets/companyLogos/asos.svg";
import chanel from "/assets/companyLogos/chanel.svg";
import gucci from "/assets/companyLogos/gucci.svg";
import celine from "/assets/companyLogos/celine.svg";
import adidas from "/assets/companyLogos/adidas.svg";

const CompanyLogo = () => {
  return (
    <div className="items-center py-17 gap-20 justify-center *:h-7 border-b mb-5 border-[#e4e4e4] grid grid-cols-2 px-8 min-sm:grid-cols-2 min-md:grid-cols-3 min-lg:flex">
      <img src={asos} alt="" />
      <img src={chanel} alt="" />
      <img src={gucci} alt="" />
      <img src={celine} alt="" />
      <img src={adidas} alt="" />
    </div>
  );
};

export default CompanyLogo;
